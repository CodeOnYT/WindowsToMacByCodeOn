For NeXus Ultimate place the folders in your Winstep/NeXuS/Backgrounds directoy.
To use the indicator place it in your Winstep/NeXuS/Indicators folder.

For RocketDock place the contents in your RocketDock/Skins directory.

-niivu