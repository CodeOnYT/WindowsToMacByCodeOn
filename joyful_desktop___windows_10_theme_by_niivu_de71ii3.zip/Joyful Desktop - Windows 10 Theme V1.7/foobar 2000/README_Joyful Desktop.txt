:: Joyful Desktop by niivu ::

Requirement:
:: foobar2000 http://www.foobar2000.org/download

Setup:
:: copy contents into your foobar folder.
:: run foobar with ColumnsUI as interface
:: go to preferences -> ColumnsUI -> Main -> use Import Button to import the eyecandy.fcl or mechanical.fcl

Best view:
:: disable toolbars (click top left edge button) and status bar.

Credits:
:: MonoLiteMod-Slim by Pengspawnie
https://www.deviantart.com/pengspawnie/art/MonoLiteMod-Slim-147924669